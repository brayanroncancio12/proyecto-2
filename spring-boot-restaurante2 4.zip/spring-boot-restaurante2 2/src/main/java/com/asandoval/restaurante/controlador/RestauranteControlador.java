package com.asandoval.restaurante.controlador;

import com.asandoval.restaurante.modelos.Ingrediente;
import com.asandoval.restaurante.modelos.Receta;
import com.asandoval.restaurante.servicio.IngredienteServicio;
import com.asandoval.restaurante.servicio.RecetaServicio;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestauranteControlador {

    RecetaServicio recetaServicio;
    IngredienteServicio ingredienteServicio;

    public RestauranteControlador(RecetaServicio recetaServicio, IngredienteServicio ingredienteServicio) {
        this.recetaServicio = recetaServicio;
        this.ingredienteServicio = ingredienteServicio;
    }

    @PostMapping("/orden")
    public String Orden() {
        Receta receta = recetaServicio.prepararPlato();
        boolean ingredientesDisponible = cantidadDisponible(receta);
        if (ingredientesDisponible) {
            prepararPlato(receta);
            return "plato preparado correctamente!";
        } else {
            return "Ingredientes no disponibles";
        }
    }

    private boolean cantidadDisponible(Receta receta) {
        for (Ingrediente ingredient : receta.getIngredientes()) {
            if (!ingredienteServicio.disponibilidadIngrediente(ingredient.getName())) {
                return false;
            }
        }
        return true;
    }

    private void prepararPlato(Receta receta) {
        for (Ingrediente ingredient : receta.getIngredientes()) {
            ingredienteServicio.useIngredients(ingredient.getName(), 1); // Suponiendo que se usa 1 unidad de cada ingrediente por receta
        }
    }


}

